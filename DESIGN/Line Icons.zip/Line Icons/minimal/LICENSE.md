What you can do
===============

- You are permitted to use the resources for any number of personal and commercial projects.
- No attribution or link back to the Duo Agency site is required, however any credit will be much appreciated.

What you can't do
=================

- You do not have the right to redistribute, resell, lease, license, sublicense or offer files downloaded from Duo Agency to any third party or as a separate attachment from any of your work. 
- If you wish to promote our resources on your site you must link back to the post itself. Pleae do not link directly to the file, or offer it for download on your server.

If you have any questions about the use of these files please email us at: hello@duo.agency